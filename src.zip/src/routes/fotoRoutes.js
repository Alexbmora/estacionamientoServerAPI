import express from 'express';
import { upload } from '../middlewares/upload.js';
import { subirFoto, listarFotos } from '../controllers/fotoController.js';

const router = express.Router();

router.post('/subir-foto', upload.single('archivo'), subirFoto);
router.get('/fotos', listarFotos);
export default router;