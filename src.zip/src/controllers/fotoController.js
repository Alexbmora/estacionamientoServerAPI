import db from '../config/db.js';

export const subirFoto = (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No se envió ninguna imagen' });

  const rutaRelativa = `/uploads/${req.file.filename}`;
  const data = {
    nombre_original: req.file.originalname,
    nombre_guardado: req.file.filename,
    ruta: rutaRelativa,
    mimetype: req.file.mimetype,
    size: req.file.size
  };

  const sql = `INSERT INTO fotos (nombre_original, nombre_guardado, ruta, mimetype, size) VALUES (?, ?, ?, ?, ?)`;
  
  db.query(sql, [data.nombre_original, data.nombre_guardado, data.ruta, data.mimetype, data.size], (err, result) => {
      if (err) {
        console.error('Error en BD:', err);
        return res.status(500).json({ error: 'Error guardando en BD' });
      }
      data.id = result.insertId;
      res.json({ mensaje: 'Foto subida correctamente', foto: data });
    }
  );
};

export const listarFotos = (req, res) => {
  db.query('SELECT * FROM fotos ORDER BY id DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Error consultando BD' });
    res.json(rows);
  });
};